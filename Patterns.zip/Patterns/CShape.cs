﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns
{
    class Shape
    {
        public IShape State{ get; set; }

        public Shape(IShape s)
        {
            State = s;
        }

        public void IncreaseSize()
        {
            State.IncreaseSize(this);
        }
        public void ReduceSize()
        {
            State.ReduceSize(this);
        }
    }

    interface IShape
    {
        void IncreaseSize(Shape shape);
        void ReduceSize(Shape shape);
    }

    class CircleShape : IShape
    {
        public void IncreaseSize(Shape shape)
        {
            shape.State = new SquareShape();
            Form1.text = "Квадрат";
        }
        public void ReduceSize(Shape shape)
        {
            //Remains the same
            Form1.text = "Круг";
        }
    }

    class SquareShape : IShape
    {
        public void IncreaseSize(Shape shape)
        {
            shape.State = new Triangle();
            Form1.text = "Треугольник";
        }
        public void ReduceSize(Shape shape)
        {
            shape.State = new CircleShape();
            Form1.text = "Круг";
        }
    }

    class Triangle : IShape
    {
        public void IncreaseSize(Shape shape)
        {
            //Remains the same
            Form1.text = "Треугольник";
        }
        public void ReduceSize(Shape shape)
        {
            shape.State = new SquareShape();
            Form1.text = "Квадрат";
        }
    }
}
