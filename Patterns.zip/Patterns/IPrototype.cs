﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns
{
    interface IPrototype
    {
        IPrototype Clone();
        float GetX();
        float GetY();
        float GetR();
    }

    class Circle: IPrototype
    {
        private float x, y, r;

        public Circle(float x, float y, float r)
        {
            this.x = x;
            this.y = y;
            this.r = r;
        }

        public IPrototype Clone()
        {
            return new Circle(this.x, this.y, this.r);
        }

        public float GetX()
        {
            return this.x;
        }
        public float GetY()
        {
            return this.y;
        }
        public float GetR()
        {
            return this.r;
        }

    }
}
