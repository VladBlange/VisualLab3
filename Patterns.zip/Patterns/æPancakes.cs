﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns
{
    abstract class Pancakes
    {
        public string Name;

        public Pancakes(string n)
        {
            this.Name = n;
        }
        
        public abstract int GetCost();
    }

    class RussianPancakes : Pancakes
    {
        public RussianPancakes(): base("Русские блинчики"){}
        public override int GetCost()
        {
            return 20;
        }
    }

    abstract class PancakesDecorator : Pancakes
    {
        protected Pancakes pancakes;
        public PancakesDecorator(string n, Pancakes pancakes) : base(n)
        {
            this.pancakes = pancakes;
        }
    }

    class Jem : PancakesDecorator
    {
        public Jem(Pancakes p): base(p.Name + ", с джемом", p){ }

        public override int GetCost()
        {
            return pancakes.GetCost() + 9;
        }
    }

    class RussianJem : PancakesDecorator
    {
        public RussianJem(Pancakes p): base(p.Name + ", с вареньем", p){ }
        public override int GetCost()
        {
            return pancakes.GetCost() + 7;
        }
    }
}
